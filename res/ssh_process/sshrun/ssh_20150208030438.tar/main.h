#ifndef _MAIN_H_
#define _MAIN_H_

#define  _CRT_SECURE_NO_WARNINGS
#ifndef  _DEBUG_
#define  _DEBUG_

#ifndef true
#define true 1
#endif

#include<stdio.h>
#include "ssh.h"
#endif  /*end of define _DEBUG_*/
#endif /*end of define _MAIN_H_*/
