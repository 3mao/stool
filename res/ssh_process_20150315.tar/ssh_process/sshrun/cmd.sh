#!/usr/bin/sh

	for i in $(seq 1 10)
	do
		echo $i
	done
